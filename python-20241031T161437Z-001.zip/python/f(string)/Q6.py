p = "                 texto com espaços ai                "
print(p.replace(" ", ""))