texto="Python é uma linguagem de programação"
print(f"{texto[13:22]}")