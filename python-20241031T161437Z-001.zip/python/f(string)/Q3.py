texto="python"
print(f"{texto[::-1]}")