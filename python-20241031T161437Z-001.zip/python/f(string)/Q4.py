texto="abcdefg"
print(f"{texto[2:5]}")