#Escreva um programa que solicite ao usuário duas strings e verifique se elas são iguais. Imprima uma mensagem informando o resultado da comparação.

s1=input("Digite uma Palavra: ")
s2=input("Digite outra Palavra: ")

if s1 == s2:
    print("As duas palavras são iguais")
else:
    print("As duas palavras são diferentes")