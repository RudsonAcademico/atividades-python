#Escreva um programa que solicite ao usuário o seu nome e a sua idade, armazenando esses valores em variáveis.
#Em seguida, imprima uma mensagem formatada mostrando o nome e a idade do usuário.

nome=input("Digite seu nome: ")
idade=input("Digite sua Idade: ")

print("Seu nome é {} e você tem {} anos".format(nome, idade))